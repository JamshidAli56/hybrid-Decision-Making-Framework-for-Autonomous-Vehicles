"""
Urban Driving Environment for Autonomous Vehicles
Multi-vehicle traffic simulation with OpenAI Gym interface
"""

import gym
from gym import spaces
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Tuple, List

class Vehicle:
    """Represents a single vehicle in the environment"""
    
    def __init__(self, vehicle_id: int, x: float = 0, y: float = 0):
        self.id = vehicle_id
        self.x = x
        self.y = y
        self.vx = 0.0
        self.vy = 0.0
        self.heading = 0.0
        self.length = 4.0
        self.width = 2.0
        self.max_speed = 10.0
        
    def update(self, ax: float, ay: float, dt: float = 0.1):
        """Update vehicle state with acceleration"""
        self.vx += ax * dt
        self.vy += ay * dt
        
        # Clip to max speed
        speed = np.sqrt(self.vx**2 + self.vy**2)
        if speed > self.max_speed:
            self.vx = (self.vx / speed) * self.max_speed
            self.vy = (self.vy / speed) * self.max_speed
        
        self.x += self.vx * dt
        self.y += self.vy * dt
        
        if speed > 0:
            self.heading = np.arctan2(self.vy, self.vx)
    
    def get_state(self) -> np.ndarray:
        """Return vehicle state vector"""
        return np.array([self.x, self.y, self.vx, self.vy, self.heading])


class UrbanDrivingEnv(gym.Env):
    """
    Custom OpenAI Gym environment for autonomous vehicle decision-making
    
    State: [ego_x, ego_y, ego_vx, ego_vy, ego_heading, 
            nearby_vehicles_states, traffic_signals]
    
    Action: [acceleration, steering]
    """
    
    metadata = {"render_modes": ["rgb_array", "human"]}
    
    def __init__(self, num_vehicles: int = 5, grid_size: float = 100.0,
                 max_steps: int = 500):
        super().__init__()
        
        self.num_vehicles = num_vehicles
        self.grid_size = grid_size
        self.max_steps = max_steps
        self.current_step = 0
        
        # Initialize vehicles
        self.vehicles = [Vehicle(i, x=np.random.uniform(0, grid_size),
                                 y=np.random.uniform(0, grid_size))
                        for i in range(num_vehicles)]
        
        # Define action and observation spaces
        # Action: [acceleration (-1 to 1), steering (-1 to 1)]
        self.action_space = spaces.Box(
            low=np.array([-1.0, -1.0]),
            high=np.array([1.0, 1.0]),
            dtype=np.float32
        )
        
        # Observation: ego state (5) + nearby vehicles (5*4) + time_step
        obs_size = 5 + (num_vehicles - 1) * 4 + 1
        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(obs_size,),
            dtype=np.float32
        )
        
        self.render_mode = None
        
    def _get_observation(self, ego_id: int = 0) -> np.ndarray:
        """Get observation for a specific vehicle"""
        ego = self.vehicles[ego_id]
        obs = [ego.x, ego.y, ego.vx, ego.vy, ego.heading]
        
        # Add relative states of nearby vehicles
        for i, vehicle in enumerate(self.vehicles):
            if i != ego_id:
                rel_x = vehicle.x - ego.x
                rel_y = vehicle.y - ego.y
                rel_vx = vehicle.vx - ego.vx
                rel_vy = vehicle.vy - ego.vy
                obs.extend([rel_x, rel_y, rel_vx, rel_vy])
        
        # Add normalized time step
        obs.append(self.current_step / self.max_steps)
        
        return np.array(obs, dtype=np.float32)
    
    def _check_collision(self) -> Tuple[bool, int, int]:
        """Check for collisions between vehicles"""
        for i in range(len(self.vehicles)):
            for j in range(i + 1, len(self.vehicles)):
                v1, v2 = self.vehicles[i], self.vehicles[j]
                dist = np.sqrt((v1.x - v2.x)**2 + (v1.y - v2.y)**2)
                min_dist = (v1.length + v2.length) / 2
                
                if dist < min_dist:
                    return True, i, j
        return False, -1, -1
    
    def _calculate_reward(self, ego_id: int, collision: bool) -> float:
        """Calculate reward for an agent"""
        reward = 0.0
        
        # Collision penalty
        if collision:
            reward -= 10.0
        
        ego = self.vehicles[ego_id]
        
        # Efficiency reward (encourage movement)
        speed = np.sqrt(ego.vx**2 + ego.vy**2)
        reward += speed / ego.max_speed * 0.1
        
        # Safe distance bonus (encourage keeping distance from others)
        min_dist_to_others = float('inf')
        for i, vehicle in enumerate(self.vehicles):
            if i != ego_id:
                dist = np.sqrt((vehicle.x - ego.x)**2 + (vehicle.y - ego.y)**2)
                min_dist_to_others = min(min_dist_to_others, dist)
        
        if min_dist_to_others > 10.0:
            reward += 0.1
        
        return reward
    
    def reset(self, seed=None) -> np.ndarray:
        """Reset environment"""
        super().reset(seed=seed)
        
        self.current_step = 0
        self.vehicles = [Vehicle(i, x=np.random.uniform(0, self.grid_size),
                                 y=np.random.uniform(0, self.grid_size))
                        for i in range(self.num_vehicles)]
        
        return self._get_observation(0)
    
    def step(self, action: np.ndarray, agent_id: int = 0) -> Tuple[np.ndarray, float, bool, dict]:
        """Execute one step of the environment"""
        self.current_step += 1
        
        # Apply action to ego vehicle
        ego = self.vehicles[agent_id]
        acceleration = action[0] * ego.max_speed
        steering = action[1]
        
        ego.update(acceleration, steering * ego.max_speed)
        
        # Random actions for other vehicles (simple behavior)
        for i, vehicle in enumerate(self.vehicles):
            if i != agent_id:
                random_action = np.random.uniform(-1, 1, 2)
                vehicle.update(random_action[0] * vehicle.max_speed,
                             random_action[1] * vehicle.max_speed)
        
        # Wrap around boundaries
        for vehicle in self.vehicles:
            vehicle.x = vehicle.x % self.grid_size
            vehicle.y = vehicle.y % self.grid_size
        
        # Check collisions
        collision, _, _ = self._check_collision()
        
        # Calculate reward
        reward = self._calculate_reward(agent_id, collision)
        
        # Episode termination
        done = collision or self.current_step >= self.max_steps
        
        # Get next observation
        obs = self._get_observation(agent_id)
        
        info = {
            'collision': collision,
            'num_vehicles': self.num_vehicles,
            'ego_speed': np.sqrt(ego.vx**2 + ego.vy**2)
        }
        
        return obs, reward, done, info
    
    def render(self):
        """Visualize the environment"""
        if self.render_mode is None:
            return
        
        # Simple text visualization (can be extended)
        print(f"Step {self.current_step}/{self.max_steps}")
        for vehicle in self.vehicles:
            print(f"Vehicle {vehicle.id}: pos=({vehicle.x:.1f}, {vehicle.y:.1f}), "
                  f"speed={np.sqrt(vehicle.vx**2 + vehicle.vy**2):.2f}")
