"""Environment module"""
