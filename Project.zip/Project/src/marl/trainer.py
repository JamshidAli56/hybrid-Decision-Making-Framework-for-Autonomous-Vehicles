"""
Multi-Agent Reinforcement Learning Framework
Orchestrates training of multiple agents with cooperation mechanisms
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
import torch
from tqdm import tqdm
import json
import os

from src.agents.dqn_agent import DQNAgent
from src.environment.urban_env import UrbanDrivingEnv
from src.explainable_ai.explainer import AttentionExplainer, DecisionLogger


class MARLTrainer:
    """
    Multi-Agent RL Trainer
    Handles training loop, agent coordination, and reward shaping
    """
    
    def __init__(self, num_agents: int, env: UrbanDrivingEnv, 
                 device: str = 'cpu', checkpoint_dir: str = './checkpoints'):
        
        self.num_agents = num_agents
        self.env = env
        self.device = device
        self.checkpoint_dir = checkpoint_dir
        
        os.makedirs(checkpoint_dir, exist_ok=True)
        
        # Create agents
        obs_dim = env.observation_space.shape[0]
        action_dim = env.action_space.shape[0]
        
        self.agents = [
            DQNAgent(obs_dim, action_dim, agent_id=i, device=device)
            for i in range(num_agents)
        ]
        
        # Explainability
        self.explainers = [AttentionExplainer(agent.q_network, device) 
                          for agent in self.agents]
        self.decision_loggers = [DecisionLogger() for _ in self.agents]
        
        # Training history
        self.episode_rewards = {i: [] for i in range(num_agents)}
        self.episode_collisions = {i: [] for i in range(num_agents)}
        
    def train_episode(self, episode: int, max_steps: int = 500,
                     batch_size: int = 32) -> Dict:
        """Train for one episode"""
        
        # Reset environment and get initial state
        state = self.env.reset()
        
        episode_rewards = {i: 0 for i in range(self.num_agents)}
        episode_collisions = {i: 0 for i in range(self.num_agents)}
        
        for step in range(max_steps):
            # Select actions for all agents
            actions = []
            for agent_id in range(self.num_agents):
                # Get observation for this agent
                obs = self.env._get_observation(agent_id)
                
                # Select action
                action = self.agents[agent_id].select_action(obs, training=True)
                actions.append(action)
            
            # Take step (for simplicity, using first agent's action)
            # In full MARL, you'd coordinate all agents
            next_state, reward, done, info = self.env.step(actions[0], agent_id=0)
            
            # All agents learn from this experience
            for agent_id in range(self.num_agents):
                obs = self.env._get_observation(agent_id)
                next_obs = self.env._get_observation(agent_id)
                
                # Store experience
                self.agents[agent_id].store_experience(
                    obs, actions[agent_id], reward, next_obs, done
                )
                
                # Train
                loss = self.agents[agent_id].train(batch_size)
                
                # Log statistics
                episode_rewards[agent_id] += reward
                if info['collision']:
                    episode_collisions[agent_id] += 1
                
                # Log for explainability
                if agent_id == 0:  # Main agent
                    q_network = self.agents[agent_id].q_network
                    state_tensor = torch.FloatTensor(obs).unsqueeze(0)
                    with torch.no_grad():
                        q_values = q_network(state_tensor)
                    q_value = q_values.max().item()
                    
                    importance = self.explainers[agent_id].get_feature_importance(obs)
                    self.decision_loggers[agent_id].log_decision(
                        step, agent_id, obs, actions[agent_id], 
                        reward, q_value, importance
                    )
            
            if done:
                break
        
        # Update networks and epsilon
        for agent in self.agents:
            agent.update_target_network()
            agent.update_epsilon()
            agent.total_episodes += 1
        
        # Store episode statistics
        for i in range(self.num_agents):
            self.episode_rewards[i].append(episode_rewards[i])
            self.episode_collisions[i].append(episode_collisions[i])
        
        return episode_rewards
    
    def train(self, num_episodes: int = 1000, eval_interval: int = 100):
        """Train agents for multiple episodes"""
        
        print(f"Starting MARL training with {self.num_agents} agents...")
        
        for episode in tqdm(range(num_episodes)):
            rewards = self.train_episode(episode)
            
            if (episode + 1) % eval_interval == 0:
                self._log_progress(episode + 1, rewards)
                self._save_checkpoint(episode + 1)
        
        print("Training completed!")
        self._save_final_results()
    
    def _log_progress(self, episode: int, rewards: Dict):
        """Log training progress"""
        avg_rewards = {agent_id: np.mean(self.episode_rewards[agent_id][-100:])
                      for agent_id in range(self.num_agents)}
        
        print(f"\nEpisode {episode}:")
        print(f"  Average Rewards: {avg_rewards}")
        print(f"  Epsilon: {self.agents[0].epsilon:.4f}")
    
    def _save_checkpoint(self, episode: int):
        """Save model checkpoints"""
        checkpoint_path = os.path.join(self.checkpoint_dir, 
                                      f'checkpoint_ep{episode}.pt')
        
        for i, agent in enumerate(self.agents):
            agent_path = checkpoint_path.replace('.pt', f'_agent{i}.pt')
            agent.save_model(agent_path)
    
    def _save_final_results(self):
        """Save final training results"""
        results = {
            'episode_rewards': self.episode_rewards,
            'episode_collisions': self.episode_collisions,
            'final_epsilon': self.agents[0].epsilon,
            'total_steps': self.agents[0].total_steps
        }
        
        with open(os.path.join(self.checkpoint_dir, 'results.json'), 'w') as f:
            json.dump(results, f, indent=2)
    
    def evaluate(self, num_episodes: int = 10, render: bool = False) -> Dict:
        """Evaluate trained agents"""
        
        eval_rewards = {i: [] for i in range(self.num_agents)}
        eval_collisions = {i: 0 for i in range(self.num_agents)}
        
        for episode in range(num_episodes):
            state = self.env.reset()
            done = False
            episode_reward = {i: 0 for i in range(self.num_agents)}
            
            while not done:
                actions = []
                for agent_id in range(self.num_agents):
                    obs = self.env._get_observation(agent_id)
                    action = self.agents[agent_id].select_action(obs, training=False)
                    actions.append(action)
                
                next_state, reward, done, info = self.env.step(actions[0], agent_id=0)
                
                for agent_id in range(self.num_agents):
                    episode_reward[agent_id] += reward
                
                if info['collision']:
                    for agent_id in range(self.num_agents):
                        eval_collisions[agent_id] += 1
        
            for agent_id in range(self.num_agents):
                eval_rewards[agent_id].append(episode_reward[agent_id])
        
        return {
            'mean_rewards': {i: np.mean(eval_rewards[i]) 
                           for i in range(self.num_agents)},
            'total_collisions': eval_collisions,
            'std_rewards': {i: np.std(eval_rewards[i]) 
                          for i in range(self.num_agents)}
        }
    
    def explain_decision(self, agent_id: int = 0, episode: int = -1):
        """Generate explanations for agent decisions"""
        
        if not self.decision_loggers[agent_id].decisions:
            print(f"No decisions logged for agent {agent_id}")
            return
        
        decisions = self.decision_loggers[agent_id].decisions
        decision = decisions[episode]
        
        explainer = self.explainers[agent_id]
        explanation = explainer.explain_action(
            decision['observation'],
            decision['action'],
            decision['q_value']
        )
        
        print(f"\nAgent {agent_id} Decision Explanation:")
        print(explanation)
        
        return explanation
