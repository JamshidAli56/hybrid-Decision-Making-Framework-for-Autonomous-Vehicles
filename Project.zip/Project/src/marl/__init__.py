"""MARL training module"""
