"""Multi-Agent RL for Autonomous Vehicles"""
__version__ = "0.1.0"
