"""
Multi-head Attention Layer for Neural Networks
Enables explainable AI through attention mechanism visualization
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple


class MultiHeadAttention(nn.Module):
    """
    Multi-head attention mechanism for feature importance and interpretability
    """
    
    def __init__(self, input_dim: int, num_heads: int = 4):
        super().__init__()
        self.input_dim = input_dim
        self.num_heads = num_heads
        self.head_dim = input_dim // num_heads
        
        assert input_dim % num_heads == 0, "input_dim must be divisible by num_heads"
        
        self.query = nn.Linear(input_dim, input_dim)
        self.key = nn.Linear(input_dim, input_dim)
        self.value = nn.Linear(input_dim, input_dim)
        self.fc_out = nn.Linear(input_dim, input_dim)
        
    def forward(self, query: torch.Tensor, key: torch.Tensor, 
                value: torch.Tensor, 
                mask: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            query, key, value: [batch_size, seq_len, input_dim]
            mask: [batch_size, 1, 1, seq_len]
        
        Returns:
            output: [batch_size, seq_len, input_dim]
            attention_weights: [batch_size, num_heads, seq_len, seq_len]
        """
        batch_size = query.shape[0]
        
        # Linear transformations
        Q = self.query(query)
        K = self.key(key)
        V = self.value(value)
        
        # Reshape for multi-head attention
        Q = Q.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        K = K.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        V = V.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        
        # Attention scores
        scores = torch.matmul(Q, K.transpose(-2, -1)) / np.sqrt(self.head_dim)
        
        if mask is not None:
            scores = scores.masked_fill(mask == 0, float('-inf'))
        
        attention_weights = F.softmax(scores, dim=-1)
        attention_weights = torch.nan_to_num(attention_weights)
        
        # Apply attention to values
        context = torch.matmul(attention_weights, V)
        
        # Concatenate heads
        context = context.transpose(1, 2).contiguous()
        context = context.view(batch_size, -1, self.input_dim)
        
        # Final linear layer
        output = self.fc_out(context)
        
        return output, attention_weights


class AttentionBasedDQN(nn.Module):
    """
    DQN with attention mechanisms for explainability
    """
    
    def __init__(self, input_dim: int, output_dim: int, 
                 hidden_dim: int = 128, num_heads: int = 4, dropout: float = 0.2):
        super().__init__()
        
        # Input projection
        self.input_layer = nn.Linear(input_dim, hidden_dim)
        
        # Attention layer
        self.attention = MultiHeadAttention(hidden_dim, num_heads)
        
        # Hidden layers
        self.hidden1 = nn.Linear(hidden_dim, hidden_dim)
        self.hidden2 = nn.Linear(hidden_dim, hidden_dim // 2)
        
        # Output layers for Q-values and value/advantage decomposition (Dueling DQN)
        self.value_stream = nn.Linear(hidden_dim // 2, 1)
        self.advantage_stream = nn.Linear(hidden_dim // 2, output_dim)
        
        self.dropout = nn.Dropout(dropout)
        self.relu = nn.ReLU()
        
        self.last_attention_weights = None
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass
        Args:
            x: [batch_size, input_dim] or [batch_size, seq_len, input_dim]
        
        Returns:
            q_values: [batch_size, output_dim]
        """
        # Handle 2D input
        if x.dim() == 2:
            x = x.unsqueeze(1)  # [batch_size, 1, input_dim]
        
        # Input projection
        h = self.relu(self.input_layer(x))
        h = self.dropout(h)
        
        # Apply self-attention
        attn_out, attention_weights = self.attention(h, h, h)
        self.last_attention_weights = attention_weights
        h = h + attn_out  # Residual connection
        
        # Hidden layers
        h = self.relu(self.hidden1(h))
        h = self.dropout(h)
        h = self.relu(self.hidden2(h))
        h = self.dropout(h)
        
        # Take mean across sequence dimension if needed
        if h.dim() == 3:
            h = h.mean(dim=1)
        
        # Dueling architecture
        value = self.value_stream(h)
        advantage = self.advantage_stream(h)
        
        # Combine value and advantages
        q_values = value + (advantage - advantage.mean(dim=1, keepdim=True))
        
        return q_values
    
    def get_attention_weights(self) -> Optional[torch.Tensor]:
        """Return last computed attention weights for visualization"""
        return self.last_attention_weights
