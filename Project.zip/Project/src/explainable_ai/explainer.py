"""
Explainability utilities for decision attribution and visualization
"""

import numpy as np
import torch
import torch.nn.functional as F
from typing import Dict, List, Tuple, Optional
import matplotlib.pyplot as plt


class AttentionExplainer:
    """Explains agent decisions using attention mechanisms"""
    
    def __init__(self, model, device='cpu'):
        self.model = model
        self.device = device
        
    def get_feature_importance(self, observation: np.ndarray) -> Dict[str, float]:
        """
        Extract feature importance from attention weights
        
        Args:
            observation: state vector from environment
            
        Returns:
            importance scores for each feature
        """
        x = torch.FloatTensor(observation).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            _ = self.model(x)
            attention_weights = self.model.get_attention_weights()
        
        if attention_weights is None:
            return {}
        
        # Average attention across heads and sequence
        avg_attention = attention_weights.mean(dim=(0, 1, 2))  # [seq_len]
        importance = avg_attention.cpu().numpy()
        
        feature_names = self._get_feature_names(observation)
        importance_dict = {name: float(imp) 
                          for name, imp in zip(feature_names, importance)}
        
        return importance_dict
    
    def _get_feature_names(self, observation: np.ndarray) -> List[str]:
        """Map feature indices to readable names"""
        num_features = len(observation)
        
        # Ego state: [x, y, vx, vy, heading]
        names = ['ego_x', 'ego_y', 'ego_vx', 'ego_vy', 'ego_heading']
        
        # Other vehicles (if present)
        remaining = num_features - len(names) - 1
        for i in range(remaining // 4):
            names.extend([f'vehicle{i}_rel_x', f'vehicle{i}_rel_y',
                         f'vehicle{i}_rel_vx', f'vehicle{i}_rel_vy'])
        
        # Time step
        if len(names) < num_features:
            names.append('time_step')
        
        return names
    
    def visualize_attention(self, observation: np.ndarray, 
                           save_path: Optional[str] = None):
        """Visualize attention weights"""
        importance = self.get_feature_importance(observation)
        
        if not importance:
            print("No attention weights available")
            return
        
        features = list(importance.keys())
        scores = list(importance.values())
        
        # Normalize scores
        max_score = max(scores) if scores else 1
        scores = [s / max_score for s in scores]
        
        plt.figure(figsize=(12, 6))
        plt.barh(features, scores, color='steelblue')
        plt.xlabel('Attention Weight (normalized)')
        plt.ylabel('Feature')
        plt.title('Feature Importance from Attention Mechanism')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
        else:
            plt.show()
    
    def explain_action(self, observation: np.ndarray, action: np.ndarray,
                      q_value: float) -> str:
        """
        Generate textual explanation for an action
        
        Args:
            observation: state vector
            action: action taken
            q_value: Q-value estimate
            
        Returns:
            explanation string
        """
        importance = self.get_feature_importance(observation)
        
        # Find top influential features
        top_features = sorted(importance.items(), key=lambda x: abs(x[1]), 
                             reverse=True)[:3]
        
        explanation = f"Action: {action}\nQ-Value: {q_value:.3f}\n"
        explanation += "Influential factors:\n"
        
        for feature, score in top_features:
            explanation += f"  - {feature}: {score:.3f}\n"
        
        return explanation


class DecisionLogger:
    """Logs and analyzes agent decisions over time"""
    
    def __init__(self):
        self.decisions = []
        
    def log_decision(self, step: int, agent_id: int, observation: np.ndarray,
                     action: np.ndarray, reward: float, q_value: float,
                     importance: Dict[str, float]):
        """Log a single decision"""
        self.decisions.append({
            'step': step,
            'agent_id': agent_id,
            'observation': observation.copy(),
            'action': action.copy(),
            'reward': reward,
            'q_value': q_value,
            'importance': importance.copy()
        })
    
    def get_statistics(self) -> Dict:
        """Compute statistics on logged decisions"""
        if not self.decisions:
            return {}
        
        rewards = [d['reward'] for d in self.decisions]
        q_values = [d['q_value'] for d in self.decisions]
        
        return {
            'mean_reward': np.mean(rewards),
            'std_reward': np.std(rewards),
            'mean_q_value': np.mean(q_values),
            'total_decisions': len(self.decisions)
        }
    
    def get_most_important_features(self, top_k: int = 5) -> List[Tuple[str, float]]:
        """Get most important features across all decisions"""
        feature_scores = {}
        
        for decision in self.decisions:
            for feature, score in decision['importance'].items():
                if feature not in feature_scores:
                    feature_scores[feature] = []
                feature_scores[feature].append(score)
        
        avg_scores = {f: np.mean(s) for f, s in feature_scores.items()}
        top_features = sorted(avg_scores.items(), key=lambda x: abs(x[1]), 
                             reverse=True)[:top_k]
        
        return top_features
