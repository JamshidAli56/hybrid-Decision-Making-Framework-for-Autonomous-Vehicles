"""Utilities module"""
import os
import json
import matplotlib.pyplot as plt
import numpy as np
from typing import Dict, List


def create_directories(paths: List[str]):
    """Create multiple directories"""
    for path in paths:
        os.makedirs(path, exist_ok=True)


def save_results(results: Dict, save_path: str):
    """Save results to JSON file"""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, 'w') as f:
        json.dump(results, f, indent=2)


def load_results(load_path: str) -> Dict:
    """Load results from JSON file"""
    with open(load_path, 'r') as f:
        return json.load(f)


def plot_training_curves(rewards: Dict, save_path: str = None):
    """Plot training reward curves"""
    plt.figure(figsize=(12, 6))
    
    for agent_id, agent_rewards in rewards.items():
        # Smooth curve with moving average
        window = 50
        smoothed = np.convolve(agent_rewards, np.ones(window)/window, mode='valid')
        plt.plot(smoothed, label=f'Agent {agent_id}', alpha=0.7)
    
    plt.xlabel('Episode')
    plt.ylabel('Cumulative Reward')
    plt.title('Training Curves - Multi-Agent RL')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    if save_path:
        plt.savefig(save_path, dpi=300)
    else:
        plt.show()


def plot_attention_heatmap(attention_weights: np.ndarray, feature_names: List[str],
                          save_path: str = None):
    """Plot attention heatmap"""
    plt.figure(figsize=(10, 8))
    plt.imshow(attention_weights, cmap='viridis', aspect='auto')
    plt.colorbar(label='Attention Weight')
    plt.yticks(range(len(feature_names)), feature_names)
    plt.xlabel('Context Position')
    plt.ylabel('Features')
    plt.title('Attention Heatmap')
    
    if save_path:
        plt.savefig(save_path, dpi=300)
    else:
        plt.show()


def moving_average(data: np.ndarray, window_size: int = 10) -> np.ndarray:
    """Compute moving average"""
    return np.convolve(data, np.ones(window_size)/window_size, mode='valid')
