"""
DQN Agent with Multi-Agent Support
Implements Q-learning with experience replay and attention mechanism
"""

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import random
from typing import Tuple, List, Optional

from src.explainable_ai.attention import AttentionBasedDQN


class ReplayBuffer:
    """Experience replay buffer for training"""
    
    def __init__(self, capacity: int = 10000):
        self.buffer = deque(maxlen=capacity)
        
    def push(self, state: np.ndarray, action: np.ndarray, reward: float,
             next_state: np.ndarray, done: bool):
        """Store experience"""
        self.buffer.append((state, action, reward, next_state, done))
    
    def sample(self, batch_size: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, 
                                               np.ndarray, np.ndarray]:
        """Sample random batch"""
        experiences = random.sample(self.buffer, min(batch_size, len(self.buffer)))
        
        states = np.array([e[0] for e in experiences])
        actions = np.array([e[1] for e in experiences])
        rewards = np.array([e[2] for e in experiences])
        next_states = np.array([e[3] for e in experiences])
        dones = np.array([e[4] for e in experiences])
        
        return states, actions, rewards, next_states, dones
    
    def __len__(self):
        return len(self.buffer)


class DQNAgent:
    """
    DQN Agent with Attention Mechanism
    Implements Deep Q-Networks for continuous action spaces
    """
    
    def __init__(self, observation_dim: int, action_dim: int, 
                 agent_id: int = 0, device: str = 'cpu',
                 learning_rate: float = 0.001, gamma: float = 0.99,
                 epsilon_start: float = 1.0, epsilon_end: float = 0.01,
                 epsilon_decay: float = 0.995):
        
        self.agent_id = agent_id
        self.device = device
        self.learning_rate = learning_rate
        self.gamma = gamma
        self.epsilon = epsilon_start
        self.epsilon_end = epsilon_end
        self.epsilon_decay = epsilon_decay
        
        # Networks
        self.q_network = AttentionBasedDQN(observation_dim, action_dim, 
                                          hidden_dim=128, num_heads=4)
        self.target_network = AttentionBasedDQN(observation_dim, action_dim, 
                                               hidden_dim=128, num_heads=4)
        self.target_network.load_state_dict(self.q_network.state_dict())
        
        self.q_network.to(device)
        self.target_network.to(device)
        
        # Optimizer
        self.optimizer = optim.Adam(self.q_network.parameters(), 
                                   lr=learning_rate)
        
        # Replay buffer
        self.replay_buffer = ReplayBuffer(capacity=10000)
        
        # Training stats
        self.total_steps = 0
        self.total_episodes = 0
        
    def select_action(self, state: np.ndarray, training: bool = True) -> np.ndarray:
        """
        Select action using epsilon-greedy policy
        For continuous action spaces, we output continuous actions
        """
        if training and random.random() < self.epsilon:
            # Random action
            return np.random.uniform(-1, 1, 2)
        
        # Greedy action
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            q_values = self.q_network(state_tensor)
        
        # For continuous actions, use a simple mapping from Q-values
        # (In practice, you might use a separate policy network)
        action = torch.tanh(q_values / 10).squeeze(0).cpu().numpy()
        return action[:2] if len(action) > 2 else action
    
    def store_experience(self, state: np.ndarray, action: np.ndarray,
                        reward: float, next_state: np.ndarray, done: bool):
        """Store experience in replay buffer"""
        self.replay_buffer.push(state, action, reward, next_state, done)
        self.total_steps += 1
    
    def train(self, batch_size: int = 32) -> Optional[float]:
        """Train on batch from replay buffer"""
        if len(self.replay_buffer) < batch_size:
            return None
        
        states, actions, rewards, next_states, dones = \
            self.replay_buffer.sample(batch_size)
        
        # Convert to tensors
        states = torch.FloatTensor(states).to(self.device)
        actions = torch.FloatTensor(actions).to(self.device)
        rewards = torch.FloatTensor(rewards).unsqueeze(1).to(self.device)
        next_states = torch.FloatTensor(next_states).to(self.device)
        dones = torch.FloatTensor(dones).unsqueeze(1).to(self.device)
        
        # Current Q-values
        current_q = self.q_network(states)
        
        # Target Q-values
        with torch.no_grad():
            next_q = self.target_network(next_states)
            max_next_q = next_q.max(dim=1, keepdim=True)[0]
            target_q = rewards + self.gamma * max_next_q * (1 - dones)
        
        # Loss
        loss = F.smooth_l1_loss(current_q, target_q)
        
        # Backpropagation
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.q_network.parameters(), 1.0)
        self.optimizer.step()
        
        return loss.item()
    
    def update_target_network(self):
        """Update target network weights"""
        self.target_network.load_state_dict(self.q_network.state_dict())
    
    def update_epsilon(self):
        """Decay epsilon"""
        self.epsilon = max(self.epsilon_end, self.epsilon * self.epsilon_decay)
    
    def save_model(self, path: str):
        """Save model checkpoint"""
        torch.save({
            'q_network': self.q_network.state_dict(),
            'target_network': self.target_network.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'epsilon': self.epsilon,
            'total_steps': self.total_steps
        }, path)
    
    def load_model(self, path: str):
        """Load model checkpoint"""
        checkpoint = torch.load(path, map_location=self.device)
        self.q_network.load_state_dict(checkpoint['q_network'])
        self.target_network.load_state_dict(checkpoint['target_network'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])
        self.epsilon = checkpoint['epsilon']
        self.total_steps = checkpoint['total_steps']


import torch.nn.functional as F
