# Implementation Guide

## Getting Started

### 1. Setup Environment

```bash
# Clone repository
cd "f:\MS\Advanced Ai\Peoject"

# Create virtual environment
python -m venv venv
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Quick Start - Training

Run basic training with default settings:
```bash
python main.py --mode train --episodes 100
```

### 3. Evaluation & Explanations

```bash
python main.py --mode eval --explain --episodes 10
```

## Project Structure

```
src/
├── environment/          # Urban driving environment
│   ├── __init__.py
│   └── urban_env.py     # Vehicle & UrbanDrivingEnv classes
├── agents/              # Agent implementations
│   ├── __init__.py
│   └── dqn_agent.py     # DQN agent with experience replay
├── marl/                # Multi-agent RL framework
│   ├── __init__.py
│   └── trainer.py       # MARLTrainer class for multi-agent training
├── explainable_ai/      # XAI components
│   ├── __init__.py
│   ├── attention.py     # Attention mechanisms & AttentionBasedDQN
│   └── explainer.py     # Explainability utilities & decision logging
└── utils/
    └── __init__.py      # Helper functions for visualization & metrics

tests/                  # Unit tests
├── test_environment.py
└── test_agents.py

config/
├── config.yaml         # Main configuration file

notebooks/              # Jupyter notebooks for demos

docs/
├── ARCHITECTURE.md     # Detailed architecture
└── IMPLEMENTATION.md   # This file
```

## Configuration

### Key Parameters (`config/config.yaml`)

**Environment**:
- `num_agents`: Number of vehicles (5)
- `grid_size`: Environment size (100x100)
- `max_steps`: Episode length (500)

**Agent Training**:
- `learning_rate`: 0.001
- `gamma`: Discount factor (0.99)
- `epsilon_start`: Initial exploration rate (1.0)
- `batch_size`: 32

**Neural Network**:
- `hidden_layers`: [128, 128, 64]
- `attention_heads`: 4 (for explainability)
- `dropout`: 0.2

**Reward Shaping**:
- `collision_penalty`: -10.0
- `efficiency_reward`: 1.0
- `safe_distance_bonus`: 0.5

## Running Experiments

### Basic Training
```bash
python main.py --config config/config.yaml --mode train --episodes 500
```

### Training with Custom Config
```bash
# Create custom_config.yaml with modifications
python main.py --config config/custom_config.yaml --mode train
```

### Evaluation with Explanations
```bash
python main.py \
  --mode eval \
  --model-path checkpoints/checkpoint_ep500_agent0.pt \
  --explain \
  --episodes 20
```

### Combined Train + Eval
```bash
python main.py --mode both --episodes 200 --explain
```

## Understanding the Code

### Environment Step
```python
obs, reward, done, info = env.step(action)
```
- `obs`: Next state observation
- `reward`: Immediate reward (-10 if collision, +0.1 for safe distance)
- `done`: Episode termination flag
- `info`: Metadata (collision status, speeds, etc.)

### Agent Training
```python
agent = DQNAgent(obs_dim=32, action_dim=2)
agent.select_action(state)  # Epsilon-greedy
agent.store_experience(state, action, reward, next_state, done)
loss = agent.train(batch_size=32)  # Mini-batch training
```

### Explainability
```python
explainer = AttentionExplainer(dqn_network)
importance = explainer.get_feature_importance(observation)
explainer.visualize_attention(observation, save_path='attention.png')
explanation = explainer.explain_action(obs, action, q_value)
```

## Extending the Framework

### Adding Custom Reward Function
Edit `src/environment/urban_env.py`:
```python
def _calculate_reward(self, ego_id: int, collision: bool) -> float:
    # Your reward logic here
    reward = 0.0
    # ... custom calculations
    return reward
```

### Custom Network Architecture
Create new class in `src/explainable_ai/attention.py`:
```python
class CustomDQN(nn.Module):
    def __init__(self, input_dim, output_dim):
        super().__init__()
        # Your layers here
```

### Different MARL Strategies
Modify `src/marl/trainer.py` `train_episode()`:
```python
# Implement cooperative/competitive strategies
# Modify reward sharing mechanisms
```

## Troubleshooting

### CUDA Out of Memory
```bash
# Reduce batch size in config.yaml
# Or disable CUDA: use_cuda: false
```

### Slow Training
- Reduce number of episodes for testing
- Use smaller network (fewer hidden units)
- Increase save_interval to reduce I/O

### Model Not Improving
- Check reward values in `_calculate_reward()`
- Increase epsilon_decay for more exploration
- Adjust learning_rate

## Performance Benchmarks

Expected performance (with default config):
- Training time: ~5-10 min for 100 episodes on CPU
- With GPU: ~1-2 min for 100 episodes
- Memory usage: ~2-3 GB
- Model file size: ~10 MB per agent

## Evaluation Metrics

The framework tracks:
1. **Reward**: Cumulative reward per episode
2. **Collisions**: Number of collision events
3. **Efficiency**: Average vehicle speed
4. **Safety**: Minimum distance to other vehicles
5. **Learning**: Q-value convergence

## Next Steps

1. Run training: `python main.py --mode train --episodes 100`
2. Evaluate: `python main.py --mode eval --explain`
3. Check results in `checkpoints/` and `results/`
4. Visualize with Jupyter notebooks in `notebooks/`
5. Modify config and experiment with parameters
