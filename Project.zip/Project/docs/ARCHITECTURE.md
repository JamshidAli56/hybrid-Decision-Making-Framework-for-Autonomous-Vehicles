# Project Documentation

## Architecture Overview

This project implements a hybrid decision-making framework for autonomous vehicles combining:

### 1. **Multi-Agent Reinforcement Learning (MARL)**
- **Framework**: Deep Q-Networks (DQN) with attention mechanisms
- **Coordination**: Agents share experience and learn collaboratively
- **Scalability**: Supports N agents in shared environment

### 2. **Custom Urban Environment**
- Vehicle dynamics simulation
- Multi-vehicle traffic scenarios
- Collision detection and reward shaping
- State: Vehicle positions, velocities, headings
- Actions: Acceleration and steering commands

### 3. **Explainable AI (XAI)**
- **Attention Mechanisms**: Multi-head self-attention for decision attribution
- **Feature Importance**: Identifies which state features drive decisions
- **Visualization**: Heatmaps and bar charts of attention weights
- **Decision Logging**: Tracks all agent actions for analysis

## Key Components

### Environment (`src/environment/urban_env.py`)
- `Vehicle`: Individual vehicle state and physics
- `UrbanDrivingEnv`: OpenAI Gym-compatible environment

### Agents (`src/agents/dqn_agent.py`)
- `ReplayBuffer`: Experience storage and sampling
- `DQNAgent`: DQN learning with attention networks

### MARL Trainer (`src/marl/trainer.py`)
- `MARLTrainer`: Coordinates multi-agent training
- Episode management, reward aggregation
- Checkpoint saving/loading

### Explainability (`src/explainable_ai/`)
- `AttentionBasedDQN`: Neural network with attention layer
- `AttentionExplainer`: Generates explanations from attention weights
- `DecisionLogger`: Records decisions for analysis

## Usage Guide

### Training
```bash
python main.py --mode train --episodes 1000
```

### Evaluation with Explanations
```bash
python main.py --mode eval --explain --model-path checkpoints/best_model.pth
```

### Configuration
Edit `config/config.yaml` to adjust:
- Number of agents
- Network architecture
- Training hyperparameters
- Reward shaping
- Explainability settings

## Algorithm Details

### DQN with Attention
1. **State Processing**: Input through attention layer
2. **Multi-Head Attention**: Identifies important features
3. **Q-Value Output**: Dueling architecture for stability
4. **Target Network**: Separate network for stable targets

### Attention Mechanism
- Maps features to query/key/value representations
- Computes attention weights across features
- Attention scores indicate feature importance
- Used for explainability and decision attribution

### Training Loop
1. Agent selects action using epsilon-greedy policy
2. Environment executes action, returns reward + next state
3. Experience stored in replay buffer
4. Mini-batch sampled and processed
5. Q-network updated with Huber loss
6. Target network periodically synchronized
7. Epsilon decay for exploration-exploitation trade-off

## Results & Analysis

### Metrics
- **Cumulative Reward**: Sum of rewards per episode
- **Collision Rate**: Percentage of episodes with collisions
- **Average Speed**: Mean vehicle velocity
- **Safety Distance**: Average distance to nearest vehicle

### Visualization
- Training curves showing reward progress
- Attention heatmaps for decision visualization
- Feature importance rankings
- Collision statistics

## Advanced Features

### Cooperative Reward Shaping
- Agents receive shared reward signals
- Encourages coordinated behavior
- Can be modified in trainer for specific coordination patterns

### Communication Protocol
- Configurable message passing between agents
- Broadcast or centralized communication
- Can be extended with graph neural networks

### Transfer Learning
- Pre-trained models can be loaded for evaluation
- Fine-tuning on new scenarios
- Checkpoint management system

## Future Enhancements

1. **Graph Neural Networks**: Better multi-agent coordination
2. **Curriculum Learning**: Progressive difficulty increase
3. **Real-World Validation**: Integration with CARLA simulator
4. **Advanced XAI**: LIME, SHAP integration
5. **Hierarchical Learning**: High-level planning + low-level control

## References

Paper implementation based on:
- "A Hybrid Decision-Making Framework for Autonomous Vehicles"
- Multi-Agent RL literature
- Explainable AI (attention mechanisms)

## License

MIT License - See LICENSE file for details
