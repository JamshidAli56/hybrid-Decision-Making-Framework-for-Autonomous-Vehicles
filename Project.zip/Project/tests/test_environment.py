"""
Unit tests for environment
"""

import pytest
import numpy as np
from src.environment.urban_env import UrbanDrivingEnv, Vehicle


class TestVehicle:
    """Test Vehicle class"""
    
    def test_vehicle_initialization(self):
        """Test vehicle initialization"""
        vehicle = Vehicle(0, x=5.0, y=10.0)
        assert vehicle.id == 0
        assert vehicle.x == 5.0
        assert vehicle.y == 10.0
    
    def test_vehicle_update(self):
        """Test vehicle physics update"""
        vehicle = Vehicle(0, x=0, y=0)
        initial_x = vehicle.x
        
        vehicle.update(ax=1.0, ay=0.0, dt=0.1)
        assert vehicle.x > initial_x  # Should move forward


class TestUrbanDrivingEnv:
    """Test UrbanDrivingEnv"""
    
    def test_env_initialization(self):
        """Test environment initialization"""
        env = UrbanDrivingEnv(num_vehicles=5, grid_size=100, max_steps=500)
        assert len(env.vehicles) == 5
        assert env.grid_size == 100
        assert env.max_steps == 500
    
    def test_reset(self):
        """Test environment reset"""
        env = UrbanDrivingEnv()
        obs = env.reset()
        
        assert obs is not None
        assert len(obs) == env.observation_space.shape[0]
    
    def test_step(self):
        """Test environment step"""
        env = UrbanDrivingEnv()
        env.reset()
        
        action = env.action_space.sample()
        obs, reward, done, info = env.step(action)
        
        assert obs is not None
        assert isinstance(reward, float)
        assert isinstance(done, bool)
        assert isinstance(info, dict)
    
    def test_observation_space(self):
        """Test observation space"""
        env = UrbanDrivingEnv(num_vehicles=3)
        env.reset()
        
        for _ in range(5):
            action = env.action_space.sample()
            obs, _, _, _ = env.step(action)
            assert obs in env.observation_space


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
