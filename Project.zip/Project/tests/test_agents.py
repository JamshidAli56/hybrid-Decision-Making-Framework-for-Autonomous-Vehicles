"""
Unit tests for agents
"""

import pytest
import numpy as np
import torch
from src.agents.dqn_agent import DQNAgent, ReplayBuffer


class TestReplayBuffer:
    """Test ReplayBuffer class"""
    
    def test_buffer_initialization(self):
        """Test buffer initialization"""
        buffer = ReplayBuffer(capacity=100)
        assert len(buffer) == 0
    
    def test_buffer_push(self):
        """Test pushing experiences"""
        buffer = ReplayBuffer(capacity=10)
        
        state = np.random.randn(5)
        action = np.array([0.5, -0.3])
        reward = 1.0
        next_state = np.random.randn(5)
        done = False
        
        buffer.push(state, action, reward, next_state, done)
        assert len(buffer) == 1
    
    def test_buffer_sample(self):
        """Test sampling from buffer"""
        buffer = ReplayBuffer(capacity=100)
        
        for _ in range(10):
            buffer.push(
                np.random.randn(5),
                np.random.randn(2),
                np.random.randn(),
                np.random.randn(5),
                False
            )
        
        states, actions, rewards, next_states, dones = buffer.sample(5)
        assert states.shape == (5, 5)
        assert actions.shape == (5, 2)


class TestDQNAgent:
    """Test DQNAgent class"""
    
    def test_agent_initialization(self):
        """Test agent initialization"""
        agent = DQNAgent(observation_dim=10, action_dim=2, agent_id=0)
        assert agent.agent_id == 0
        assert agent.total_steps == 0
    
    def test_action_selection(self):
        """Test action selection"""
        agent = DQNAgent(observation_dim=10, action_dim=2)
        state = np.random.randn(10)
        
        action = agent.select_action(state, training=True)
        assert action.shape == (2,)
        assert np.all(action >= -1) and np.all(action <= 1)
    
    def test_experience_storage(self):
        """Test storing experiences"""
        agent = DQNAgent(observation_dim=10, action_dim=2)
        
        state = np.random.randn(10)
        action = np.array([0.5, -0.3])
        reward = 1.0
        next_state = np.random.randn(10)
        done = False
        
        agent.store_experience(state, action, reward, next_state, done)
        assert len(agent.replay_buffer) == 1


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
