# Hybrid Decision-Making Framework for Autonomous Vehicles

A Python-based implementation of a multi-agent reinforcement learning framework with explainable AI for autonomous vehicle decision-making in urban environments.

## Project Overview

This project implements:
- **Multi-Agent RL (MARL)**: Cooperative decision-making among multiple autonomous agents
- **Custom Urban Environment**: Simulated urban driving scenarios with traffic interactions
- **Explainable AI**: Attention mechanisms for model interpretability
- **OpenAI Gym Integration**: Standard RL environment interface

## Project Structure

```
├── src/
│   ├── environment/       # Urban environment simulation
│   ├── agents/           # Agent implementations
│   ├── marl/             # Multi-agent RL logic
│   ├── explainable_ai/   # Attention mechanisms & XAI
│   └── utils/            # Utility functions
├── tests/                # Unit tests
├── notebooks/            # Jupyter notebooks
├── config/               # Configuration files
├── docs/                 # Documentation
├── requirements.txt      # Dependencies
└── main.py              # Entry point
```

## Setup & Installation

1. **Create virtual environment**:
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

## Key Components

### 1. Urban Environment
- Multi-vehicle traffic scenarios
- Reward functions for safe/efficient driving
- State representation (ego position, surrounding vehicles, road info)

### 2. MARL Framework
- Independent learners with communication
- Cooperative reward shaping
- Experience sharing

### 3. Agents
- DQN with attention mechanisms
- Policy networks with explainability
- Experience replay & training loops

### 4. Explainable AI
- Attention visualization
- Decision attribution
- Feature importance analysis

## Usage

### Training
```bash
python main.py --mode train --episodes 1000 --agents 5
```

### Evaluation & Explanation
```bash
python main.py --mode eval --model_path ./checkpoints/best_model.pth --explain
```

### Visualization
```bash
jupyter notebook notebooks/
```

## Documentation

See [docs/](docs/) for:
- Architecture details
- Algorithm specifications
- Experimental results

## Contributing

Guidelines for adding new components (coming soon)

## License

MIT License
