"""
Main entry point for MARL Autonomous Vehicle Training
"""

import argparse
import os
import yaml
import torch
import numpy as np

from src.environment.urban_env import UrbanDrivingEnv
from src.marl.trainer import MARLTrainer
from src.explainable_ai.explainer import AttentionExplainer


def load_config(config_path: str) -> dict:
    """Load configuration from YAML file"""
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config


def train_mode(config: dict, args: argparse.Namespace):
    """Training mode"""
    print("=" * 60)
    print("Starting Multi-Agent RL Training")
    print("=" * 60)
    
    # Set seeds
    seed = config['random_seed']
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    # Create environment
    env = UrbanDrivingEnv(
        num_vehicles=config['environment']['num_agents'],
        grid_size=config['environment']['grid_size'],
        max_steps=config['environment']['max_steps']
    )
    
    # Determine device
    device = 'cuda' if config.get('use_cuda', True) and torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")
    
    # Create trainer
    trainer = MARLTrainer(
        num_agents=config['environment']['num_agents'],
        env=env,
        device=device,
        checkpoint_dir=config['experiment']['checkpoint_dir']
    )
    
    # Train
    num_episodes = args.episodes if args.episodes else config['training']['num_episodes']
    trainer.train(num_episodes=num_episodes, 
                 eval_interval=config['experiment']['save_interval'])
    
    print("\n" + "=" * 60)
    print("Training completed!")
    print(f"Checkpoints saved to: {config['experiment']['checkpoint_dir']}")
    print("=" * 60)
    
    return trainer


def eval_mode(config: dict, args: argparse.Namespace, trainer: MARLTrainer = None):
    """Evaluation mode"""
    print("=" * 60)
    print("Starting Evaluation")
    print("=" * 60)
    
    if trainer is None:
        # Create fresh environment and trainer
        device = 'cuda' if config.get('use_cuda', True) and torch.cuda.is_available() else 'cpu'
        env = UrbanDrivingEnv(
            num_vehicles=config['environment']['num_agents'],
            grid_size=config['environment']['grid_size'],
            max_steps=config['environment']['max_steps']
        )
        trainer = MARLTrainer(
            num_agents=config['environment']['num_agents'],
            env=env,
            device=device,
            checkpoint_dir=config['experiment']['checkpoint_dir']
        )
        
        # Load model if specified
        if args.model_path and os.path.exists(args.model_path):
            trainer.agents[0].load_model(args.model_path)
            print(f"Loaded model from: {args.model_path}")
    
    # Evaluate
    num_eval_episodes = args.episodes if args.episodes else 10
    results = trainer.evaluate(num_episodes=num_eval_episodes, render=True)
    
    print("\nEvaluation Results:")
    print(f"Mean Rewards: {results['mean_rewards']}")
    print(f"Std Rewards: {results['std_rewards']}")
    print(f"Total Collisions: {results['total_collisions']}")
    
    # Explain if requested
    if args.explain:
        print("\n" + "-" * 60)
        print("Generating Explanations...")
        print("-" * 60)
        
        for agent_id in range(len(trainer.agents)):
            try:
                trainer.explain_decision(agent_id=agent_id)
                
                # Visualize attention
                if trainer.decision_loggers[agent_id].decisions:
                    last_decision = trainer.decision_loggers[agent_id].decisions[-1]
                    obs = last_decision['observation']
                    
                    save_path = os.path.join(
                        config['experiment']['result_dir'],
                        f'attention_viz_agent{agent_id}.png'
                    )
                    os.makedirs(os.path.dirname(save_path), exist_ok=True)
                    trainer.explainers[agent_id].visualize_attention(obs, save_path)
                    print(f"Attention visualization saved to: {save_path}")
            except Exception as e:
                print(f"Error generating explanations for agent {agent_id}: {e}")
    
    print("\n" + "=" * 60)
    print("Evaluation completed!")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(
        description="Multi-Agent RL for Autonomous Vehicles"
    )
    
    parser.add_argument('--config', type=str, default='config/config.yaml',
                       help='Path to config file')
    parser.add_argument('--mode', type=str, choices=['train', 'eval', 'both'],
                       default='train', help='Run mode')
    parser.add_argument('--episodes', type=int, default=None,
                       help='Number of episodes (overrides config)')
    parser.add_argument('--model-path', type=str, default=None,
                       help='Path to trained model for evaluation')
    parser.add_argument('--explain', action='store_true',
                       help='Generate explanations during evaluation')
    
    args = parser.parse_args()
    
    # Load config
    if not os.path.exists(args.config):
        print(f"Config file not found: {args.config}")
        print("Using default configuration...")
        # Create default config paths if needed
    
    config = load_config(args.config) if os.path.exists(args.config) else {}
    
    # Set defaults if not in config
    if not config:
        config = {
            'environment': {'num_agents': 5, 'grid_size': 100.0, 'max_steps': 500},
            'training': {'num_episodes': 100},
            'experiment': {'checkpoint_dir': './checkpoints', 'save_interval': 10,
                          'result_dir': './results'},
            'random_seed': 42,
            'use_cuda': True
        }
    
    trainer = None
    
    # Execute modes
    if args.mode in ['train', 'both']:
        trainer = train_mode(config, args)
    
    if args.mode in ['eval', 'both']:
        eval_mode(config, args, trainer)


if __name__ == '__main__':
    main()
